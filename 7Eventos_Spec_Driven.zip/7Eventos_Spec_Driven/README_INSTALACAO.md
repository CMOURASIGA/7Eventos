# Pacote de documentação Spec Driven - 7Eventos

Este pacote reorganiza a documentação existente e adiciona a camada Spec Driven.

## Aplicação no repositório
Copie a pasta `docs` deste pacote para a raiz do repositório 7Eventos. Os documentos originais foram preservados dentro de `docs/00-product` e `docs/phases`.

Antes de remover os cinco arquivos antigos da raiz de `docs`, confirme o diff. O objetivo é mover, não perder conteúdo.

## Entrada para o dev
Entregue sempre `docs/DEV_START_HERE.md` e o ID da SPEC a executar.
