param([string]$RepoPath = ".")
$ErrorActionPreference = "Stop"
$source = Join-Path $PSScriptRoot "docs"
$target = Join-Path $RepoPath "docs"
$backup = Join-Path $RepoPath ("docs_backup_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
if (Test-Path $target) { Copy-Item $target $backup -Recurse -Force; Write-Host "Backup: $backup" }
New-Item -ItemType Directory -Force -Path $target | Out-Null
Copy-Item (Join-Path $source "*") $target -Recurse -Force
Write-Host "Estrutura Spec Driven copiada para $target"
Write-Host "Revise com: git status e git diff"
